# nokia3310-jam-godot-starter
A Godot starter project for the nokia3310 game jam

Use this project to get a kick start for the Nokia 3310 Jam on itch.io!
[Link to the Jam](https://itch.io/jam/nokiajam2)


Everything inside the Game.tscn scene will be rendered with two colors from the official palette while also applying an ordered dithering shader.  

![Example screen](/example.png)